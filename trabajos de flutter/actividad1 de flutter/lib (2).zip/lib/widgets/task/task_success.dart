// TODO Implement this library.
import 'package:flutter/material.dart';

class TaskSuccess extends StatelessWidget {
  const TaskSuccess({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black54),
        borderRadius: BorderRadius.circular(8),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Comprar", style: TextStyle(fontWeight: FontWeight.bold)),
          Text("Ir al Ara"),
          Divider(),
          Text("Tránsito", style: TextStyle(fontWeight: FontWeight.bold)),
          Text("Trámite"),
        ],
      ),
    );
  }
}
