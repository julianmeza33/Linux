import 'package:flutter/material.dart';

class UserSuccess extends StatelessWidget {
  const UserSuccess({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      height: 150,
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black54),
        borderRadius: BorderRadius.circular(8),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Hola, Carlos", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text("Contacto: usuario@gmail.com"),
          Text("Saldo: 1200"),
        ],
      ),
    );
  }
}
